package balextranit;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CompanyTest {

    @Test
    public void testSchedulePickup_Success() {
        Company company = new Company();
        Vehicle taxi = new Taxi(4);
        company.addVehicle(taxi);

        Passenger passenger = new Passenger(new Location(10, 20), new Location(50, 60));
        boolean result = company.schedulePickup(passenger);

        assertTrue(result, "Expected pickup to be scheduled");
    }

    @Test
    public void testSchedulePickup_NoVehicles() {
        Company company = new Company();
        Passenger passenger = new Passenger(new Location(10, 20), new Location(50, 60));
        boolean result = company.schedulePickup(passenger);

        assertFalse(result, "Expected pickup to fail due to no vehicles");
    }
}