package balextranit;

public class Taxi extends Vehicle {
    private int seats;

    public Taxi(int seats) {
        this.seats = seats;
    }

    @Override
    public void assignPassenger(Passenger passenger) {
        available = false;
        System.out.println("Taxi assigned to passenger from " +
            passenger.getPickupLocation() + " to " + passenger.getDestinationLocation());
    }
}