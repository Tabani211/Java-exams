package balextranit;

import java.util.ArrayList;
import java.util.List;

public class Company {
    private List<Vehicle> vehicles = new ArrayList<>();

    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }

    public boolean schedulePickup(Passenger passenger) {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.isAvailable()) {
                vehicle.assignPassenger(passenger);
                return true;
            }
        }
        return false;
    }
}