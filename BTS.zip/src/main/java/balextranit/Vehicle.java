package balextranit;

public abstract class Vehicle {
    protected boolean available = true;

    public boolean isAvailable() {
        return available;
    }

    public abstract void assignPassenger(Passenger passenger);
}