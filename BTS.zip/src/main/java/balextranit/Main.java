package balextranit;

public class Main {
    public static void main(String[] args) {
        Company company = new Company();
        company.addVehicle(new Taxi(4));

        PassengerSource source = new PassengerSource(company);
        boolean success = source.requestPickup();

        System.out.println("Pickup success: " + success);
    }
}