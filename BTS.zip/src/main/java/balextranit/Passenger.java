package balextranit;

public class Passenger {
    private Location pickupLocation;
    private Location destinationLocation;

    public Passenger(Location pickup, Location destination) {
        this.pickupLocation = pickup;
        this.destinationLocation = destination;
    }

    public Location getPickupLocation() {
        return pickupLocation;
    }

    public Location getDestinationLocation() {
        return destinationLocation;
    }
}