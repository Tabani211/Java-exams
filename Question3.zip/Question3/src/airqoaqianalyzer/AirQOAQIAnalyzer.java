package airqoaqianalyzer;

import java.util.Arrays;
import java.util.Random;

public class AirQOAQIAnalyzer {

    public static void main(String[] args) {
        final int DAYS = 30;
        int[] aqiReadings = new int[DAYS];
        Random rand = new Random();

        // i) Generate 30 random AQI readings between 1 and 300
        for (int i = 0; i < DAYS; i++) {
            aqiReadings[i] = rand.nextInt(300) + 1; // Range: 1 to 300
        }

        // Display AQI readings
        System.out.println("AQI Readings for 30 Days:");
        System.out.println(Arrays.toString(aqiReadings));

        // ii) Compute and display the median AQI
        int[] sortedReadings = aqiReadings.clone();
        Arrays.sort(sortedReadings);

        double median;
        if (DAYS % 2 == 0) {
            // Average of middle two elements
            int mid1 = DAYS / 2 - 1;
            int mid2 = DAYS / 2;
            median = (sortedReadings[mid1] + sortedReadings[mid2]) / 2.0;
        } else {
            median = sortedReadings[DAYS / 2];
        }

        System.out.println("Median AQI: " + median);

        // iii) Count number of hazardous days (AQI > 200)
        int hazardousDays = 0;
        for (int aqi : aqiReadings) {
            if (aqi > 200) {
                hazardousDays++;
            }
        }

        System.out.println("Number of Hazardous Days (AQI > 200): " + hazardousDays);
    }
}
