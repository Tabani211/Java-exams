
package efris;

public class Main {
    public static void main(String[] args) {
        TransactionRecord record = new TransactionRecord();
        record.setBuyerTIN("123456789");
        record.setSellerTIN("987654321");
        record.setInvoiceAmount(2500.75);
        record.setTransactionTimestamp("2025-07-05T14:30:00");

        System.out.println("Buyer TIN: " + record.getBuyerTIN());
        System.out.println("Seller TIN: " + record.getSellerTIN());
        System.out.println("Invoice Amount: " + record.getInvoiceAmount());
        System.out.println("Timestamp: " + record.getTransactionTimestamp());
    }
}
