
package efris;

// Base class
abstract class TaxCategory {
    public abstract double calculateVAT(double amount);
}

// Subclass for Retailer
class Retailer extends TaxCategory {
    @Override
    public double calculateVAT(double amount) {
        return amount * 0.18; // 18% VAT
    }
}

// Subclass for Wholesaler
class Wholesaler extends TaxCategory {
    @Override
    public double calculateVAT(double amount) {
        return amount * 0.15; // 15% VAT
    }
}

// Subclass for Importer
class Importer extends TaxCategory {
    @Override
    public double calculateVAT(double amount) {
        return amount * 0.10; // 10% VAT
    }
}

// Subclass for Manufacturer
class Manufacturer extends TaxCategory {
    @Override
    public double calculateVAT(double amount) {
        return amount * 0.12; // 12% VAT
    }
}

// Main class to demonstrate runtime polymorphism
public class VATCalculator {
    public static void main(String[] args) {
        TaxCategory[] taxpayers = {
            new Retailer(),
            new Wholesaler(),
            new Importer(),
            new Manufacturer()
        };

        double[] amounts = {1000.0, 2000.0, 1500.0, 3000.0};

        for (int i = 0; i < taxpayers.length; i++) {
            double vat = taxpayers[i].calculateVAT(amounts[i]);
            System.out.println(taxpayers[i].getClass().getSimpleName() +
                " - Amount: " + amounts[i] + ", VAT: " + vat);
        }
    }
}
